package javaBasico;

import java.util.Scanner;

public class Exercise1 {

    public static void main(String[] args) {

        // 1.1 Numericos Enteros

        byte variable1 = 5;
        short variable2 = 10;
        int variable3 = 30;
        long variable4 = 100;

        // 1.2 Numericos decimales

        float variabl5 = 5.5f;
        double variabl6 = 20.5d;

        // 2.Booleano

        boolean variable7 = true;
        boolean variable8 = false;

        // 3.Texto

        char variable9 = 'a';
        String variable10 = "Lorem ipsum dolor sit amet...";


        }

    }

