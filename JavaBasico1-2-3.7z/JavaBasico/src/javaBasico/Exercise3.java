package javaBasico;

import java.util.ArrayList;
import java.util.List;

public class Exercise3 {

    public static void main(String[] args) {

        List<String> nombres = new ArrayList<>();

        nombres.add("Pepe ");
        nombres.add("Eustakio ");
        nombres.add("Alvaro ");
        nombres.add("Mario ");

        for (String nombre : nombres) {
            System.out.print(nombre);


        }
    }
}