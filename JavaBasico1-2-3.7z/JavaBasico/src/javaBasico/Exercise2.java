package javaBasico;

import java.util.Scanner;

public class Exercise2 {

    public static double calcularIVA(double precioDeLaCompra) {

        double IVA;
        IVA = precioDeLaCompra * 0.21;
        return IVA;
    }
    public static void main(String[] args) {

        // Crear una funcion que reciba un precio y devuelva el precio con el IVA incluido 21%

        Scanner lector = new Scanner(System.in);

        double precioDeLaCompra, IVA;

        System.out.println("Ingrese el precio total de la compra");
        precioDeLaCompra = lector.nextDouble();

        IVA = calcularIVA(precioDeLaCompra);

        System.out.println("El precio total sin IVA es de: "+precioDeLaCompra);
        System.out.println("El precio a pagar (IVA incluido) es de: "+(precioDeLaCompra+IVA));

    }
}
